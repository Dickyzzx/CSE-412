package com.demo.service.impl;

import com.demo.dao.Impl.SellerSuppDaoImpl;
import com.demo.dao.SellerSuppDao;
import com.demo.entity.SellerSupp;
import com.demo.entity.dto.UserMap;
import com.demo.entity.tableData.SellerAndOrderTableData;
import com.demo.service.SellerSuppService;
import com.demo.util.AuthUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.List;

public class SellerSuppServiceImpl implements SellerSuppService {

    private SellerSuppDao sellerSuppDao = new SellerSuppDaoImpl();


    @Override
    public ObservableList<SellerAndOrderTableData> getAllTableData(String keyWords) {
        if (AuthUtil.isLogin()) {
            return null;
        }
        return conversion(sellerSuppDao.selectAll(keyWords));
    }

    @Override
    public List<SellerSupp> selectSellerSuppByUid() {
        if (AuthUtil.isLogin()) {
            return null;
        }
        return sellerSuppDao.selectByUid(UserMap.getUid());
    }


    public ObservableList<SellerAndOrderTableData> conversion(List<SellerSupp> list) {
        ObservableList<SellerAndOrderTableData> observableList = FXCollections.observableArrayList();
        for (SellerSupp vo : list) {
            observableList.add(new SellerAndOrderTableData(vo.getUid(), vo.getPid(), vo.getIdentifier().toString(), vo.getPrice().toString()));
        }
        return observableList;
    }
}
