package com.demo.service;

import com.demo.entity.Pets;
import com.demo.entity.tableData.PetsTableData;
import javafx.collections.ObservableList;

import java.util.List;

public interface PetsService extends IService<Pets> {

    ObservableList<PetsTableData> getAllTableData(String name);

    ObservableList<PetsTableData>  getAllTableDataByUidOrName(String name);

    Boolean deletePets(String id);

    Boolean buyPets(String id);
}
