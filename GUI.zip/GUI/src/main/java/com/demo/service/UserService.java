package com.demo.service;

import com.demo.entity.User;
import com.demo.entity.tableData.UserTableData;
import javafx.collections.ObservableList;

import java.util.List;

public interface UserService extends IService<User> {

    public User login(String uid, String password);


    public ObservableList<UserTableData> getAllUserTableData(String name);

    public List<String> getUids();

    Boolean updateByUid(User user);
}
