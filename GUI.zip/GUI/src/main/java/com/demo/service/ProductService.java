package com.demo.service;

import com.demo.entity.Product;
import com.demo.entity.tableData.ProductTableData;
import javafx.collections.ObservableList;

import java.util.List;

public interface ProductService extends IService<Product> {

    ObservableList<ProductTableData> getAllTableData(String desc);

    ObservableList<ProductTableData> getAllTableDataByUidOrDesc(String desc);

    Boolean deleteProduct(String id);

    Boolean buyProduct(String id);
}
