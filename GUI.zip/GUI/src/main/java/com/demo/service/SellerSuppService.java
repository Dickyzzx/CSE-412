package com.demo.service;

import com.demo.entity.SellerSupp;
import com.demo.entity.tableData.SellerAndOrderTableData;
import javafx.collections.ObservableList;

import java.util.List;

public interface SellerSuppService {

    public ObservableList<SellerAndOrderTableData> getAllTableData(String keyWords);

    List<SellerSupp> selectSellerSuppByUid();

}
