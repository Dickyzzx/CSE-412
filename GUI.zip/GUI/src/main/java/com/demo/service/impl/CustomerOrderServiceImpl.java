package com.demo.service.impl;

import com.demo.dao.CustomerOrderDao;
import com.demo.dao.Impl.CustomerOrderDaoImpl;
import com.demo.entity.CustomerOrder;
import com.demo.entity.SellerSupp;
import com.demo.entity.dto.UserMap;
import com.demo.entity.tableData.SellerAndOrderTableData;
import com.demo.service.CustomerOrderService;
import com.demo.util.AuthUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.List;

public class CustomerOrderServiceImpl implements CustomerOrderService {

    private CustomerOrderDao orderDao = new CustomerOrderDaoImpl();


    @Override
    public List<CustomerOrder> selectOrderByUid() {
        if (AuthUtil.isLogin()) {
            return null;
        }
        return orderDao.selectByUid(UserMap.getUid());
    }

    @Override
    public ObservableList<SellerAndOrderTableData> getAllTableData(String keyWords) {
        if (AuthUtil.isLogin()) {
            return null;
        }
        return conversion(orderDao.selectAll(keyWords));
    }

    public ObservableList<SellerAndOrderTableData> conversion(List<CustomerOrder> list) {
        ObservableList<SellerAndOrderTableData> observableList = FXCollections.observableArrayList();
        for (CustomerOrder vo : list) {
            observableList.add(new SellerAndOrderTableData(vo.getUid(), vo.getPid(), vo.getIdentifier().toString(), vo.getPrice().toString()));
        }
        return observableList;
    }

}
