package com.demo.service;

import com.demo.entity.CustomerOrder;
import com.demo.entity.tableData.SellerAndOrderTableData;
import javafx.collections.ObservableList;

import java.util.List;

public interface CustomerOrderService {

    List<CustomerOrder> selectOrderByUid();

    ObservableList<SellerAndOrderTableData> getAllTableData(String keyWords);
}
