package com.demo.service.impl;

import com.demo.dao.Impl.UserDaoImpl;
import com.demo.dao.UserDao;
import com.demo.entity.User;
import com.demo.entity.dto.UserMap;
import com.demo.entity.tableData.UserTableData;
import com.demo.service.UserService;
import com.demo.util.AuthUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.List;

public class UserServiceImpl implements UserService {

    private UserDao userDao = new UserDaoImpl();

    public Boolean saveOne(User entity) {
        //user already exists
        if (userDao.selectCountByUid(entity.getUid()) > 0) {
            return false;
        }
        return userDao.insertOne(entity);
    }


    public User login(String uid, String password) {
        return userDao.selectUserByUidAndPassword(uid, password);
    }


    @Override
    public ObservableList<UserTableData> getAllUserTableData(String name) {
        if (AuthUtil.isLogin()) {
            return null;
        }
        return conversion(userDao.selectAll(name));
    }

    @Override
    public List<String> getUids() {
        if (AuthUtil.isLogin()) {
            return null;
        }
        return userDao.getUids();
    }

    @Override
    public Boolean updateByUid(User user) {
        if (AuthUtil.isLogin()) {
            return false;
        }
        return userDao.updateUserByUid(user);
    }

    public ObservableList<UserTableData> conversion(List<User> list) {
        ObservableList<UserTableData> observableList = FXCollections.observableArrayList();
        for (User vo : list) {
            observableList.add(new UserTableData(vo.getUid(), vo.getName(), vo.getPhone(), vo.getZipCode(), vo.getEmail()));
        }
        return observableList;
    }
}
