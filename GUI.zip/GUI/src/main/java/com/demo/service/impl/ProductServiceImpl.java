package com.demo.service.impl;

import com.demo.dao.Impl.ProductDaoImpl;
import com.demo.dao.ProductDao;
import com.demo.entity.Product;
import com.demo.entity.dto.UserMap;
import com.demo.entity.tableData.ProductTableData;
import com.demo.service.ProductService;
import com.demo.util.AuthUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.List;

public class ProductServiceImpl implements ProductService {

    private ProductDao productDao = new ProductDaoImpl();

    @Override
    public ObservableList<ProductTableData> getAllTableData(String desc) {
        if (AuthUtil.isLogin()) {
            return null;
        }
        return conversion(productDao.selectAll(desc));
    }

    @Override
    public ObservableList<ProductTableData> getAllTableDataByUidOrDesc(String desc) {
        if (AuthUtil.isLogin()) {
            return null;
        }
        return conversion(productDao.selectProductsByUid(UserMap.getUid(), desc));
    }

    @Override
    public Boolean deleteProduct(String id) {
        if (AuthUtil.isLogin()) {
            return null;
        }
        return productDao.deleteById(id);
    }

    @Override
    public Boolean buyProduct(String id) {
        if (AuthUtil.isLogin()) {
            return false;
        }
        return productDao.buyProduct(id);
    }

    @Override
    public Boolean saveOne(Product entity) {
        if (AuthUtil.isLogin()) {
            return null;
        }
        entity.setSellerUid(UserMap.getUid());
        return productDao.insertOne(entity);
    }

    public ObservableList<ProductTableData> conversion(List<Product> list) {
        ObservableList<ProductTableData> observableList = FXCollections.observableArrayList();
        for (Product vo : list) {
            observableList.add(new ProductTableData(vo.getId(), vo.getDescription(),
                    vo.getBrand(), vo.getPrice().toString(),
                    vo.getStatus(), vo.getSellerUid()));
        }
        return observableList;
    }
}
