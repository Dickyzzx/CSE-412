package com.demo.service.impl;

import com.demo.dao.Impl.PetsDaoIml;
import com.demo.dao.PetsDao;
import com.demo.entity.Pets;
import com.demo.entity.dto.UserMap;
import com.demo.entity.tableData.PetsTableData;
import com.demo.service.PetsService;
import com.demo.util.AuthUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.List;

public class PetsServiceImpl implements PetsService {

    private PetsDao petsDao = new PetsDaoIml();

    public Boolean saveOne(Pets entity) {
        if (AuthUtil.isLogin()) {
            return false;
        }
        entity.setSellerUid(UserMap.getUid());
        return petsDao.insertOne(entity);
    }

    public ObservableList<PetsTableData> getAllTableData(String name) {
        if (AuthUtil.isLogin()) {
            return null;
        }
        return conversion(petsDao.selectAll(name));
    }

    public ObservableList<PetsTableData> getAllTableDataByUidOrName(String name) {
        if (AuthUtil.isLogin()) {
            return null;
        }
        return conversion(petsDao.selectPetsByUid(UserMap.getUid(), name));
    }

    public Boolean deletePets(String id) {
        if (AuthUtil.isLogin()) {
            return false;
        }
        return petsDao.deleteById(id);
    }

    @Override
    public Boolean buyPets(String id) {
        if (AuthUtil.isLogin()) {
            return false;
        }
        return petsDao.buyPets(id);
    }

    public ObservableList<PetsTableData> conversion(List<Pets> list) {
        ObservableList<PetsTableData> observableList = FXCollections.observableArrayList();
        for (Pets vo : list) {
            observableList.add(new PetsTableData(
                    vo.getId(),
                    vo.getName(),
                    vo.getAge().toString(),
                    vo.getLocation(),
                    vo.getSpecies(),
                    vo.getBreed(),
                    vo.getPrice().toString(),
                    vo.getSellerUid(),
                    vo.getStatus()
            ));
        }
        return observableList;
    }
}
