package com.demo.controller;

import com.demo.common.AlertUtilCommon;
import com.demo.entity.dto.UserMap;
import com.demo.entity.tableData.PetsTableData;
import com.demo.service.PetsService;
import com.demo.service.impl.PetsServiceImpl;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;

import java.net.URL;
import java.util.ResourceBundle;

public class MyPetListController implements Initializable {
    @FXML
    private TableColumn<PetsTableData, String> id;
    @FXML
    private TableColumn<PetsTableData, String> name;
    @FXML
    private TableColumn<PetsTableData, String> age;
    @FXML
    private TableColumn<PetsTableData, String> location;
    @FXML
    private TableColumn<PetsTableData, String> species;
    @FXML
    private TableColumn<PetsTableData, String> breed;
    @FXML
    private TableColumn<PetsTableData, String> price;
    @FXML
    private TableColumn<PetsTableData, String> status;
    @FXML
    private TableColumn operation;
    @FXML
    private TextField searchText;
    @FXML
    private TableView<PetsTableData> petsListView;
    private PetsService petsService = new PetsServiceImpl();


    @Override
    public void initialize(URL url, ResourceBundle resources) {
        petsTableDataInit(petsListView, id, name, age, location, species, breed, price, status, operation,
                petsService.getAllTableDataByUidOrName(null));
    }

    private void petsTableDataInit(TableView<PetsTableData> petsListView,
                                   TableColumn<PetsTableData, String> id,
                                   TableColumn<PetsTableData, String> name,
                                   TableColumn<PetsTableData, String> age,
                                   TableColumn<PetsTableData, String> location,
                                   TableColumn<PetsTableData, String> species,
                                   TableColumn<PetsTableData, String> breed,
                                   TableColumn<PetsTableData, String> price,
                                   TableColumn<PetsTableData, String> status,
                                   TableColumn operation,
                                   ObservableList<PetsTableData> data) {

        id.setCellValueFactory(d -> d.getValue().getId());
        name.setCellValueFactory(d -> d.getValue().getName());
        age.setCellValueFactory(d -> d.getValue().getAge());
        location.setCellValueFactory(d -> d.getValue().getLocation());
        species.setCellValueFactory(d -> d.getValue().getSpecies());
        breed.setCellValueFactory(d -> d.getValue().getBreed());
        price.setCellValueFactory(d -> d.getValue().getPrice());
        status.setCellValueFactory(d -> d.getValue().getStatus().get().equals("2") ?
                new SimpleStringProperty("Purchased") :
                new SimpleStringProperty("Hot Sale"));
        operation.setCellFactory((col) -> {
            TableCell<PetsTableData, String> cell = new TableCell<PetsTableData, String>() {
                public HBox addButton = new HBox();
                Label delBtn = new Label("DEL");

                {
                    addButton.getStylesheets().add("view/css/user.css");
                    addButton.setAlignment(Pos.CENTER);
                    delBtn.getStyleClass().addAll("delBtn", "btn");
                    addButton.getChildren().addAll(delBtn);
                }

                @Override
                protected void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    if (!empty) {

                        delBtn.setOnMouseClicked((m) -> {
                            PetsTableData selectedItem = getTableView().getSelectionModel().getSelectedItem();
                            if (selectedItem.getStatus().get().equals("2") || !selectedItem.getSellerUid().get().equals(UserMap.getUid())) {
                                new AlertUtilCommon().AlterMessageInform(delBtn.getScene().getWindow(),
                                        Alert.AlertType.ERROR, "error", "You can't delete pets that have already been purchased or that you didn't publish  ", "delete failed!");
                            } else if (new AlertUtilCommon().AlterMessageOption(delBtn.getScene().getWindow(), "selection",
                                    "confirm", "cancel", "delete tip", "Whether to delete the pet？")) {
                                petsService.deletePets(selectedItem.getId().get());
                                initialize(null, null);
                            }
                        });
                        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
                        setGraphic(addButton);
                    } else {
                        setGraphic(null);
                    }
                }
            };
            return cell;
        });
        petsListView.setItems(data);

    }

    public void searchBtnAction(ActionEvent actionEvent) {
        String text = searchText.getText();
        petsTableDataInit(petsListView, id, name, age, location, species, breed, price, status, operation,
                petsService.getAllTableDataByUidOrName(text));
    }
}
