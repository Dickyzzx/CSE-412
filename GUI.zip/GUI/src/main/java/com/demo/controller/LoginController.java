package com.demo.controller;

import com.alibaba.druid.util.StringUtils;
import com.demo.Main;
import com.demo.entity.User;
import com.demo.entity.dto.UserMap;
import com.demo.service.UserService;
import com.demo.service.impl.UserServiceImpl;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class LoginController implements Initializable {

    @FXML
    private Button cancelBtn;

    @FXML
    private TextField accountTextField;

    @FXML
    private PasswordField passwordTextField;

    @FXML
    private Label tipMessageLabel;

    private UserService userService = new UserServiceImpl();

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }

    public void loginBtnOnAction(ActionEvent actionEvent) {
        String account = accountTextField.getText();
        String password = passwordTextField.getText();
        if (StringUtils.isEmpty(account) || StringUtils.isEmpty(password)) {
            tipMessageLabel.setText("The user name or password cannot be empty");
        } else if (password.length() < 6) {
            tipMessageLabel.setText("The password contains less than 6 characters");
        } else {
            User user = userService.login(account, password);
            if (user == null) {
                tipMessageLabel.setText("The username does not exist or the password is incorrect");
            } else {
                this.cancelBtnOnAction();
                UserMap.setUid(account);
                UserMap.setPassword(password);
                UserMap.setName(user.getName());
                Stage h = new Main().homePageInit();
                tipMessageLabel.setText("login successful！！");
                System.out.println(UserMap.getUid() + "--------" + UserMap.getName());
                h.showAndWait();
            }
        }


    }

    public void cancelBtnOnAction() {
        Stage stage = (Stage) cancelBtn.getScene().getWindow();
        stage.close();
    }

    public void registerBtnOnAction(ActionEvent actionEvent) {
        Stage h = new Main().registerPageInit();
        h.showAndWait();
    }
}
