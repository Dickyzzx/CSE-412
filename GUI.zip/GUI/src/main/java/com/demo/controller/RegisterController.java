package com.demo.controller;

import com.alibaba.druid.util.StringUtils;
import com.demo.common.AlertUtilCommon;
import com.demo.entity.User;
import com.demo.service.impl.UserServiceImpl;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class RegisterController implements Initializable {


    @FXML
    private TextField addUid;
    @FXML
    private TextField addPhone;
    @FXML
    private TextField addName;
    @FXML
    private TextField addEmail;
    @FXML
    private TextField addZipCode;
    @FXML
    private AnchorPane registerScene;


    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }

    public void addUserAction(ActionEvent actionEvent) {
        String username = addName.getText();
        String account = addUid.getText();
        String phone = addPhone.getText();
        String email = addEmail.getText();
        String zipCode = addZipCode.getText();
        if (StringUtils.isEmpty(username) || StringUtils.isEmpty(account)) {
            new AlertUtilCommon().AlterMessageInform(registerScene.getScene().getWindow(),
                    Alert.AlertType.WARNING, "error",
                    "username or uid is must be not empty", "param error!");
        } else {
            User user = new User();
            user.setZipCode(zipCode);
            user.setUid(account);
            user.setPhone(phone);
            user.setName(username);
            user.setEmail(email);
            Boolean aBoolean = new UserServiceImpl().saveOne(user);
            if (aBoolean) {
                new AlertUtilCommon().AlterMessageOption(registerScene.getScene().getWindow(),
                        "Sure to add this user?",
                        "Confirm",
                        "Cancel",
                        "register user",
                        "register user");
                this.backLoginAction();

            } else {
                new AlertUtilCommon().AlterMessageInform(registerScene.getScene().getWindow(),
                        Alert.AlertType.WARNING, "warning",
                        "register failed", "add user!");
            }

        }

    }

    public void backLoginAction() {
        Stage stage = (Stage) registerScene.getScene().getWindow();
        stage.close();
    }
}
