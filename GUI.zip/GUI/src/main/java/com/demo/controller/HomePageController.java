package com.demo.controller;

import com.demo.Main;
import com.demo.common.AlertUtilCommon;
import com.demo.entity.dto.UserMap;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class HomePageController implements Initializable {


    @FXML
    private AnchorPane mainFrameAnchorPane;
    @FXML
    private AnchorPane tempFrameAnchorPane;


    private void resetAnchorPane() {
        mainFrameAnchorPane.getChildren().clear();
        mainFrameAnchorPane.getChildren().add(tempFrameAnchorPane);
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }

    public void setMainFrameAnchorPane(AnchorPane mainFrameAnchorPane) {
        this.mainFrameAnchorPane = mainFrameAnchorPane;
    }

    public void do_userList_event(ActionEvent actionEvent) {
        tempFrameAnchorPane = new Main().initMainFrame("/view/UserList.fxml");
        resetAnchorPane();
    }

    public void do_queryPetsMenuItem_event(ActionEvent actionEvent) {
        tempFrameAnchorPane = new Main().initMainFrame("/view/PetList.fxml");
        resetAnchorPane();
    }

    public void do_addPetsMenuItem_event(ActionEvent actionEvent) {
        tempFrameAnchorPane = new Main().initMainFrame("/view/AddPets.fxml");
        resetAnchorPane();
    }

    public void do_queryProductMenuItem_event(ActionEvent actionEvent) {
        tempFrameAnchorPane = new Main().initMainFrame("/view/ProductList.fxml");
        resetAnchorPane();
    }

    public void do_addProductMenuItem_event(ActionEvent actionEvent) {
        tempFrameAnchorPane = new Main().initMainFrame("/view/AddProduct.fxml");
        resetAnchorPane();
    }

    public void do_querySellerSuppMenuItem_event(ActionEvent actionEvent) {
        tempFrameAnchorPane = new Main().initMainFrame("/view/SellerSuppList.fxml");
        resetAnchorPane();
    }

    public void do_orderMenuItem_event(ActionEvent actionEvent) {
        tempFrameAnchorPane = new Main().initMainFrame("/view/OrderSuppList.fxml");
        resetAnchorPane();
    }

    public void do_toUpdatePerson(ActionEvent actionEvent) {
        tempFrameAnchorPane = new Main().initMainFrame("/view/EditUser.fxml");
        resetAnchorPane();
    }

    public void do_toLoginMenuItem_event(ActionEvent actionEvent) {
        Boolean aBoolean = new AlertUtilCommon().AlterMessageOption(mainFrameAnchorPane.getScene().getWindow(), "Whether to exit the system？",
                "Confirm the exit", "Cancel exit", "System Prompt", "Is the host really leaving?");
        if (aBoolean) {
            Stage stage = (Stage) mainFrameAnchorPane.getScene().getWindow();
            stage.close();
            UserMap.setName(null);
            UserMap.setPassword(null);
            UserMap.setName(null);
            new Main().start(stage);
        }
    }

    public void do_queryPetsMenuItemBySelf_event(ActionEvent actionEvent) {
        tempFrameAnchorPane = new Main().initMainFrame("/view/MyPetList.fxml");
        resetAnchorPane();
    }

    public void do_queryProductMenuItemBySelf_event(ActionEvent actionEvent) {
        tempFrameAnchorPane = new Main().initMainFrame("/view/MyProductList.fxml");
        resetAnchorPane();
    }
}
