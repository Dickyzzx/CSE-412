package com.demo.controller;

import com.demo.common.AlertUtilCommon;
import com.demo.entity.dto.UserMap;
import com.demo.entity.tableData.ProductTableData;
import com.demo.service.ProductService;
import com.demo.service.impl.ProductServiceImpl;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;

import java.net.URL;
import java.util.ResourceBundle;

public class ProductListController implements Initializable {

    @FXML
    private TableColumn<ProductTableData, String> id;
    @FXML
    private TableColumn<ProductTableData, String> desc;
    @FXML
    private TableColumn<ProductTableData, String> brand;
    @FXML
    private TableColumn<ProductTableData, String> price;
    @FXML
    private TableColumn<ProductTableData, String> status;

    @FXML
    private TableColumn operation;
    @FXML
    private TextField searchText;
    @FXML
    private TableView<ProductTableData> productListView;
    private ProductService productService = new ProductServiceImpl();


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        productTableInit(productListView, id, desc, brand, price, status, operation, productService.getAllTableData(null));
    }

    private void productTableInit(TableView<ProductTableData> productListView,
                                  TableColumn<ProductTableData, String> id,
                                  TableColumn<ProductTableData, String> desc,
                                  TableColumn<ProductTableData, String> brand,
                                  TableColumn<ProductTableData, String> price,
                                  TableColumn<ProductTableData, String> status,
                                  TableColumn operation,
                                  ObservableList<ProductTableData> data) {
        id.setCellValueFactory(d -> d.getValue().getId());
        desc.setCellValueFactory(d -> d.getValue().getDescription());
        brand.setCellValueFactory(d -> d.getValue().getBrand());
        price.setCellValueFactory(d -> d.getValue().getPrice());
        status.setCellValueFactory(d -> d.getValue().getStatus().get().equals("2") ?
                new SimpleStringProperty("Purchased") :
                new SimpleStringProperty("Hot Sale"));
        operation.setCellFactory((col) -> {
            TableCell<ProductTableData, String> cell = new TableCell<ProductTableData, String>() {
                public HBox addButton = new HBox();
                Label delBtn = new Label("DEL");
                Label buyBtn = new Label("BUY");
                Label empty = new Label("   ");

                {
                    addButton.getStylesheets().add("view/css/user.css");
                    addButton.setAlignment(Pos.CENTER);
                    delBtn.getStyleClass().addAll("delBtn", "btn");
                    buyBtn.getStyleClass().addAll("editBtn", "btn");
                    addButton.getChildren().addAll(buyBtn, empty, delBtn);
                }

                @Override
                protected void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    if (!empty) {

                        delBtn.setOnMouseClicked((m) -> {
                            ProductTableData selectedItem = getTableView().getSelectionModel().getSelectedItem();
                            if (selectedItem.getStatus().get().equals("2") || !selectedItem.getSellerUid().get().equals(UserMap.getUid())) {
                                new AlertUtilCommon().AlterMessageInform(delBtn.getScene().getWindow(),
                                        Alert.AlertType.ERROR, "error", "You can't delete product that have already been purchased or that you didn't publish  ", "delete failed!");
                            } else if (new AlertUtilCommon().AlterMessageOption(delBtn.getScene().getWindow(), "selection",
                                    "confirm", "cancel", "delete tip", "Whether to delete the product？")) {
                                productService.deleteProduct(selectedItem.getId().get());
                                initialize(null, null);
                            }
                        });

                        buyBtn.setOnMouseClicked((m) -> {


                            ProductTableData selectedItem = getTableView().getSelectionModel().getSelectedItem();
                            if (selectedItem.getStatus().get().equals("2") || selectedItem.getSellerUid().get().equals(UserMap.getUid())) {
                                new AlertUtilCommon().AlterMessageInform(delBtn.getScene().getWindow(),
                                        Alert.AlertType.ERROR, "error", "You cannot buy product that you have posted or that have already been purchased", "buy failed!");
                            } else if (new AlertUtilCommon().AlterMessageOption(delBtn.getScene().getWindow(), "selection",
                                    "confirm", "cancel", "buy tip", "Sure to buy a new product?？")) {
                                productService.buyProduct(selectedItem.getId().get());
                                initialize(null, null);
                            }
                        });
                        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
                        setGraphic(addButton);
                    } else {
                        setGraphic(null);
                    }
                }
            };
            return cell;
        });
        productListView.setItems(data);


    }

    public void searchBtnAction(ActionEvent actionEvent) {
        String text = searchText.getText();
        productTableInit(productListView, id, desc, brand, price, status, operation, productService.getAllTableData(text));

    }
}
