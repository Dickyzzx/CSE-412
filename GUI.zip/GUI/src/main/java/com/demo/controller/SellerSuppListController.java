package com.demo.controller;

import com.demo.entity.tableData.SellerAndOrderTableData;
import com.demo.service.SellerSuppService;
import com.demo.service.impl.SellerSuppServiceImpl;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.TextFieldTableCell;

import java.net.URL;
import java.util.ResourceBundle;

public class SellerSuppListController implements Initializable {


    @FXML
    private TableColumn<SellerAndOrderTableData, String> uid;
    @FXML
    private TableColumn<SellerAndOrderTableData, String> pid;
    @FXML
    private TableColumn<SellerAndOrderTableData, String> buyType;
    @FXML
    private TableColumn<SellerAndOrderTableData, String> price;

    @FXML
    private TextField searchText;
    @FXML
    private TableView<SellerAndOrderTableData> sellerSuppListView;
    private SellerSuppService sellerSuppService = new SellerSuppServiceImpl();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        sellerSuppTableData(sellerSuppListView, uid, pid, buyType, price, sellerSuppService.getAllTableData(null));
    }

    private void sellerSuppTableData(TableView<SellerAndOrderTableData> sellerSuppListView,
                                     TableColumn<SellerAndOrderTableData, String> uid,
                                     TableColumn<SellerAndOrderTableData, String> pid,
                                     TableColumn<SellerAndOrderTableData, String> buyType,
                                     TableColumn<SellerAndOrderTableData, String> price,
                                     ObservableList<SellerAndOrderTableData> data) {
        uid.setCellValueFactory(d -> d.getValue().getUid());
        pid.setCellValueFactory(d -> d.getValue().getPid());
        buyType.setCellValueFactory(d -> d.getValue().getIdentifier().get().equals("1") ?
                new SimpleStringProperty("pet")
                : new SimpleStringProperty("product"));
        price.setCellValueFactory(d -> d.getValue().getPrice());
        pid.setCellFactory(TextFieldTableCell.forTableColumn());

        sellerSuppListView.setEditable(true);
        sellerSuppListView.setItems(data);
    }

    public void searchBtnAction(ActionEvent actionEvent) {
        String text = searchText.getText();
        sellerSuppTableData(sellerSuppListView, uid, pid, buyType, price, sellerSuppService.getAllTableData(text));

    }
}
