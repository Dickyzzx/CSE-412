package com.demo.controller;

import com.alibaba.druid.util.StringUtils;
import com.demo.Main;
import com.demo.common.AlertUtilCommon;
import com.demo.entity.User;
import com.demo.entity.dto.UserMap;
import com.demo.service.UserService;
import com.demo.service.impl.UserServiceImpl;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class EditUserController implements Initializable {

    @FXML
    private TextField name;
    @FXML
    private TextField phone;
    @FXML
    private TextField zipCode;
    @FXML
    private TextField email;
    @FXML
    private TextField password;

    private AlertUtilCommon alertUtilCommon = new AlertUtilCommon();

    @FXML
    private AnchorPane editUserAnchorPane;

    private UserService userService = new UserServiceImpl();


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        userMessageInit();
    }

    public void userMessageInit() {
        User user = userService.login(UserMap.getUid(), UserMap.getPassword());
        if (user != null) {
            name.setText(user.getName());
            phone.setText(user.getPhone());
            zipCode.setText(user.getZipCode());
            password.setText(user.getPassword());
            email.setText(user.getEmail());
        }
    }

    public void editUserAction(ActionEvent actionEvent) {
        String username = name.getText();
        String userPassword = password.getText();
        String userZipCode = zipCode.getText();
        String userEmail = email.getText();
        String userPhone = phone.getText();

        if (StringUtils.isEmpty(username) || StringUtils.isEmpty(userPassword)) {
            alertUtilCommon.AlterMessageInform(editUserAnchorPane.getScene().getWindow(),
                    Alert.AlertType.ERROR, "error",
                    "name,uid,password is must be not empty",
                    "param is empty tips");
        } else {
            if (userPassword.length() < 6) {
                alertUtilCommon.AlterMessageInform(editUserAnchorPane.getScene().getWindow(),
                        Alert.AlertType.ERROR, "update tips",
                        "password is not enough 6 digits", "Almost succeeded in modifying");
            } else {
                User user = new User();
                user.setPhone(userPhone);
                user.setPassword(userPassword);
                user.setEmail(userEmail);
                user.setZipCode(userZipCode);
                user.setName(username);
                user.setUid(UserMap.getUid());
                Boolean b = userService.updateByUid(user);
                if (b) {
                    alertUtilCommon.AlterMessageInform(name.getScene().getWindow(),
                            Alert.AlertType.CONFIRMATION,
                            "edit tips",
                            "edit successful",
                            "successful");
                    if (UserMap.getPassword().equals(userPassword)) {
                        AnchorPane anchorPane = (AnchorPane) editUserAnchorPane.getParent();
                        HomePageController homePageController = new HomePageController();
                        homePageController.setMainFrameAnchorPane(anchorPane);
                        homePageController.do_userList_event(null);
                    } else {
                        Stage stage = (Stage) editUserAnchorPane.getScene().getWindow();
                        stage.close();
                        UserMap.setName(null);
                        UserMap.setPassword(null);
                        UserMap.setUid(null);
                        new Main().start(stage);
                    }
                } else {
                    alertUtilCommon.AlterMessageInform(editUserAnchorPane.getScene().getWindow(),
                            Alert.AlertType.ERROR, "error", "edit failed", "operation failed");
                }
            }
        }
    }

    public void resetUserAction(ActionEvent actionEvent) {
        name.setText("");
        phone.setText("");
        zipCode.setText("");
        password.setText("");
        email.setText("");
    }
}
