package com.demo.controller;

import com.alibaba.druid.util.StringUtils;
import com.demo.common.AlertUtilCommon;
import com.demo.entity.Product;
import com.demo.service.ProductService;
import com.demo.service.impl.ProductServiceImpl;
import com.demo.util.StringUtil;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

import java.math.BigDecimal;
import java.net.URL;
import java.util.ResourceBundle;

public class AddProductController implements Initializable {

    @FXML
    private TextField addDesc;
    @FXML
    private TextField addBrand;
    @FXML
    private TextField addPrice;
    @FXML
    private AnchorPane addProductScene;

    private ProductService productService = new ProductServiceImpl();

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }


    public void addProductAction(ActionEvent actionEvent) {

        String desc = addDesc.getText();
        String brand = addBrand.getText();
        String price = addPrice.getText();
        if (StringUtils.isEmpty(desc) || StringUtils.isEmpty(brand) || StringUtils.isEmpty(price)) {
            new AlertUtilCommon().AlterMessageInform(addProductScene.getScene().getWindow(),
                    Alert.AlertType.ERROR, "error",
                    "desc or brand or price is must be not empty", "add failed!");
        } else if (!StringUtil.isNumber(price)) {
            new AlertUtilCommon().AlterMessageInform(addProductScene.getScene().getWindow(),
                    Alert.AlertType.ERROR, "error",
                    "The price must be a positive integer or a floating point number", "add failed!");
        } else {
            Product product = new Product();
            product.setPrice(new BigDecimal(price));
            product.setDescription(desc);
            product.setBrand(brand);
            Boolean b = productService.saveOne(product);
            if (b) {

                new AlertUtilCommon().AlterMessageOption(addProductScene.getScene().getWindow(),
                        "Sure to add this product?",
                        "Confirm",
                        "Cancel",
                        "add product",
                        "add product");
                AnchorPane anchorPane = (AnchorPane) addProductScene.getParent();
                HomePageController homePageController = new HomePageController();
                homePageController.setMainFrameAnchorPane(anchorPane);
                homePageController.do_queryProductMenuItem_event(null);

            } else {
                new AlertUtilCommon().AlterMessageInform(addProductScene.getScene().getWindow(),
                        Alert.AlertType.WARNING, "warning",
                        "add failed", "add product!");
            }
        }

    }

    public void resetUserAction(ActionEvent actionEvent) {
        addPrice.setText("");
        addBrand.setText("");
        addDesc.setText("");
    }
}
