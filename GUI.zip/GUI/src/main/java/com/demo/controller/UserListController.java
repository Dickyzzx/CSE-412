package com.demo.controller;

import com.demo.entity.tableData.UserTableData;
import com.demo.service.UserService;
import com.demo.service.impl.UserServiceImpl;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

public class UserListController implements Initializable {

    @FXML
    private TableColumn<UserTableData, String> uid;
    @FXML
    private TableColumn<UserTableData, String> name;
    @FXML
    private TableColumn<UserTableData, String> phone;
    @FXML
    private TableColumn<UserTableData, String> zipCode;
    @FXML
    private TableColumn<UserTableData, String> email;
    @FXML
    private TableView<UserTableData> userListView;
    @FXML
    private TextField searchText;

    private UserService userService = new UserServiceImpl();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        userTableDataInit(userListView, uid, name, phone, zipCode, email, userService.getAllUserTableData(null));
    }

    private void userTableDataInit(TableView<UserTableData> userListView,
                                   TableColumn<UserTableData, String> uid,
                                   TableColumn<UserTableData, String> name,
                                   TableColumn<UserTableData, String> phone,
                                   TableColumn<UserTableData, String> zipCode,
                                   TableColumn<UserTableData, String> email,
                                   ObservableList<UserTableData> allUserTableData) {
        uid.setCellValueFactory(d -> d.getValue().getUid());
        name.setCellValueFactory(d -> d.getValue().getName());
        phone.setCellValueFactory(d -> d.getValue().getPhone());
        zipCode.setCellValueFactory(d -> d.getValue().getZipCode());
        email.setCellValueFactory(d -> d.getValue().getEmail());
        userListView.setItems(allUserTableData);
    }

    public void searchBtnAction(ActionEvent actionEvent) {
        String text = searchText.getText();
        userTableDataInit(userListView, uid, name, phone, zipCode, email, userService.getAllUserTableData(text));
    }
}
