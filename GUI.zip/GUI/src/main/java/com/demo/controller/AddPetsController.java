package com.demo.controller;

import com.alibaba.druid.util.StringUtils;
import com.demo.common.AlertUtilCommon;
import com.demo.entity.Pets;
import com.demo.service.PetsService;
import com.demo.service.impl.PetsServiceImpl;
import com.demo.util.StringUtil;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

import java.math.BigDecimal;
import java.net.URL;
import java.util.ResourceBundle;

public class AddPetsController implements Initializable {

    @FXML
    private TextField addName;
    @FXML
    private TextField addLocation;
    @FXML
    private TextField addBreed;
    @FXML
    private TextField addAge;
    @FXML
    private TextField addSpecies;
    @FXML
    private TextField addPrice;
    @FXML
    private AnchorPane addPetsScene;


    private PetsService petsService = new PetsServiceImpl();

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }

    public void addPetAction(ActionEvent actionEvent) {
        String name = addName.getText();
        String location = addLocation.getText();
        String age = addAge.getText();
        String breed = addBreed.getText();
        String species = addSpecies.getText();
        String price = addPrice.getText();

        if (StringUtils.isEmpty(name) || StringUtils.isEmpty(age) || StringUtils.isEmpty(price)) {
            new AlertUtilCommon().AlterMessageInform(addPetsScene.getScene().getWindow(),
                    Alert.AlertType.ERROR, "error",
                    "name or age or price is must be not empty", "add failed!");
        } else if (!StringUtil.isNumber(age)) {
            new AlertUtilCommon().AlterMessageInform(addPetsScene.getScene().getWindow(),
                    Alert.AlertType.ERROR, "error",
                    "Age must be a positive integer", "add failed!");
        } else if (!StringUtil.isNumber(price)) {
            new AlertUtilCommon().AlterMessageInform(addPetsScene.getScene().getWindow(),
                    Alert.AlertType.ERROR, "error",
                    "price must be a positive integer or double", "add failed!");
        } else if (Integer.valueOf(age) <= 0 || Integer.valueOf(age) >= 100) {
            new AlertUtilCommon().AlterMessageInform(addPetsScene.getScene().getWindow(),
                    Alert.AlertType.ERROR, "error",
                    "Age must be between 1 and 100", "add failed!");
        } else {
            Pets pets = new Pets();
            pets.setName(name);
            pets.setAge(Integer.valueOf(age));
            pets.setPrice(new BigDecimal(price));
            pets.setBreed(breed);
            pets.setLocation(location);
            pets.setSpecies(species);
            Boolean b = petsService.saveOne(pets);
            if (b) {
                new AlertUtilCommon().AlterMessageOption(addPetsScene.getScene().getWindow(),
                        "Sure to add this pet?",
                        "Confirm",
                        "Cancel",
                        "add pet",
                        "add pet");
                AnchorPane anchorPane = (AnchorPane) addPetsScene.getParent();
                HomePageController homePageController = new HomePageController();
                homePageController.setMainFrameAnchorPane(anchorPane);
                homePageController.do_queryPetsMenuItem_event(null);

            } else {
                new AlertUtilCommon().AlterMessageInform(addPetsScene.getScene().getWindow(),
                        Alert.AlertType.WARNING, "warning",
                        "add failed", "add pets!");
            }
        }


    }

    public void resetUserAction(ActionEvent actionEvent) {
        addName.setText("");
        addLocation.setText("");
        addBreed.setText("");
        addSpecies.setText("");
        addPrice.setText("");
        addAge.setText("");
    }
}
