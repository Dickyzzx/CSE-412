package com.demo.dao;

import com.demo.entity.User;

import java.util.List;

public interface UserDao extends BaseDao<User> {

    long selectCountByUid(String uid);

    User selectUserByUidAndPassword(String uid, String password);


    List<User> selectAll(String name);

    List<String> getUids();

    Boolean updateUserByUid(User user);
}
