package com.demo.dao;

import com.demo.entity.Pets;

import java.util.List;

public interface PetsDao extends BaseDao<Pets> {

    List<Pets> selectAll(String name);

    List<Pets> selectPetsByUid(String uid, String name);

    Boolean deleteById(String id);

    Boolean buyPets(String id);
}
