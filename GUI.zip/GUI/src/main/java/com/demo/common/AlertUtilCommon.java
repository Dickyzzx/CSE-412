package com.demo.common;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.stage.Window;

import java.util.Optional;

/**
 * @author fengq
 */
public class AlertUtilCommon {
    /**
     * @param window
     * @param contentText
     * @param tButtonText
     * @param fButtonText
     * @param title
     * @param headText
     * @return
     */
    public Boolean AlterMessageOption(Window window, String contentText, String tButtonText, String fButtonText, String title, String headText ){
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION,contentText,new ButtonType(fButtonText, ButtonBar.ButtonData.NO),
                new ButtonType(tButtonText, ButtonBar.ButtonData.YES));
        alert.initOwner(window);
        alert.setTitle(title);
        alert.setHeaderText(headText);
        Optional<ButtonType> buttonType = alert.showAndWait();
        if(buttonType.get().getButtonData().equals(ButtonBar.ButtonData.YES)){
            return true;
        }else {
            return false;
        }
    }

    public void AlterMessageInform(Window window,Alert.AlertType alertType,String title,String contentText,String headerText){
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.initOwner(window);
        alert.setHeaderText(headerText);
        alert.setContentText(contentText);
        alert.showAndWait();
    }
}
