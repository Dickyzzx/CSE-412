package com.demo.util;

import java.util.regex.Pattern;

public class StringUtil {

    public static Boolean isNumber(String text) {
        String pattern = "^[+]?([0-9]*\\.?[0-9]+|[0-9]+\\.?[0-9]*)([eE][+-]?[0-9]+)?$";
        return Pattern.matches(pattern, text);
    }
}
