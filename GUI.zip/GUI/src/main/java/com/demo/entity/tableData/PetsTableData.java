package com.demo.entity.tableData;

import javafx.beans.property.SimpleStringProperty;

public class PetsTableData {

    private SimpleStringProperty id;
    private SimpleStringProperty name;
    private SimpleStringProperty age;
    private SimpleStringProperty location;
    private SimpleStringProperty species;
    private SimpleStringProperty breed;
    private SimpleStringProperty price;
    private SimpleStringProperty sellerUid;
    private SimpleStringProperty status;


    public SimpleStringProperty getId() {
        return id;
    }

    public void setId(String id) {
        this.id.set(id);
    }

    public SimpleStringProperty getName() {
        return name;
    }


    public void setName(String name) {
        this.name.set(name);
    }

    public SimpleStringProperty getAge() {
        return age;
    }


    public void setAge(String age) {
        this.age.set(age);
    }

    public SimpleStringProperty getLocation() {
        return location;
    }


    public void setLocation(String location) {
        this.location.set(location);
    }

    public SimpleStringProperty getSpecies() {
        return species;
    }


    public void setSpecies(String species) {
        this.species.set(species);
    }

    public SimpleStringProperty getBreed() {
        return breed;
    }


    public void setBreed(String breed) {
        this.breed.set(breed);
    }

    public SimpleStringProperty getPrice() {
        return price;
    }


    public void setPrice(String price) {
        this.price.set(price);
    }

    public SimpleStringProperty getSellerUid() {
        return sellerUid;
    }


    public void setSellerUid(String sellerUid) {
        this.sellerUid.set(sellerUid);
    }

    public SimpleStringProperty getStatus() {
        return status;
    }


    public void setStatus(String status) {
        this.status.set(status);
    }

    public PetsTableData(String id, String name,
                         String age, String location,
                         String species, String breed,
                         String price,
                         String sellerUid, String status) {
        this.id = new SimpleStringProperty(id);
        this.name = new SimpleStringProperty(name);
        this.age = new SimpleStringProperty(age);
        this.location = new SimpleStringProperty(location);
        this.species = new SimpleStringProperty(species);
        this.breed = new SimpleStringProperty(breed);
        this.price = new SimpleStringProperty(price);
        this.sellerUid = new SimpleStringProperty(sellerUid);
        this.status = new SimpleStringProperty(status);
    }
}
