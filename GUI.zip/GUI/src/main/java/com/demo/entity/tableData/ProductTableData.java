package com.demo.entity.tableData;

import javafx.beans.property.SimpleStringProperty;

public class ProductTableData {

    private SimpleStringProperty id;
    private SimpleStringProperty description;
    private SimpleStringProperty brand;
    private SimpleStringProperty price;
    private SimpleStringProperty status;
    private SimpleStringProperty sellerUid;

    public SimpleStringProperty getId() {
        return id;
    }

    public void setId(String id) {
        this.id.set(id);
    }

    public SimpleStringProperty getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description.set(description);
    }

    public SimpleStringProperty getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand.set(brand);
    }

    public SimpleStringProperty getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price.set(price);
    }

    public SimpleStringProperty getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status.set(status);
    }

    public SimpleStringProperty getSellerUid() {
        return sellerUid;
    }


    public void setSellerUid(String sellerUid) {
        this.sellerUid.set(sellerUid);
    }

    public ProductTableData(String id, String description,
                            String brand, String price,
                            String status, String sellerUid) {
        this.id = new SimpleStringProperty(id);
        this.description = new SimpleStringProperty(description);
        this.brand = new SimpleStringProperty(brand);
        this.price = new SimpleStringProperty(price);
        this.status = new SimpleStringProperty(status);
        this.sellerUid = new SimpleStringProperty(sellerUid);
    }
}
