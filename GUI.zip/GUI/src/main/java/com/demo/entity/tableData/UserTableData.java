package com.demo.entity.tableData;

import javafx.beans.property.SimpleStringProperty;

public class UserTableData {

    private SimpleStringProperty uid;
    private SimpleStringProperty name;
    private SimpleStringProperty phone;
    private SimpleStringProperty zipCode;
    private SimpleStringProperty email;


    public SimpleStringProperty getUid() {
        return uid;
    }


    public void setUid(String uid) {
        this.uid.set(uid);
    }

    public SimpleStringProperty getName() {
        return name;
    }


    public void setName(String name) {
        this.name.set(name);
    }

    public SimpleStringProperty getPhone() {
        return phone;
    }


    public void setPhone(String phone) {
        this.phone.set(phone);
    }

    public SimpleStringProperty getZipCode() {
        return zipCode;
    }


    public void setZipCode(String zipCode) {
        this.zipCode.set(zipCode);
    }

    public SimpleStringProperty getEmail() {
        return email;
    }


    public void setEmail(String email) {
        this.email.set(email);
    }

    public UserTableData(String uid, String name, String phone,
                         String zipCode, String email) {
        this.uid = new SimpleStringProperty(uid);
        this.name = new SimpleStringProperty(name);
        this.phone = new SimpleStringProperty(phone);
        this.zipCode = new SimpleStringProperty(zipCode);
        this.email = new SimpleStringProperty(email);
    }
}
