package com.demo.entity.tableData;

import javafx.beans.property.SimpleStringProperty;

public class SellerAndOrderTableData {

    private SimpleStringProperty uid;
    private SimpleStringProperty pid;
    private SimpleStringProperty identifier;
    private SimpleStringProperty price;


    public SimpleStringProperty getUid() {
        return uid;
    }


    public void setUid(String uid) {
        this.uid.set(uid);
    }

    public SimpleStringProperty getPid() {
        return pid;
    }


    public void setPid(String pid) {
        this.pid.set(pid);
    }

    public SimpleStringProperty getIdentifier() {
        return identifier;
    }


    public void setIdentifier(String identifier) {
        this.identifier.set(identifier);
    }

    public SimpleStringProperty getPrice() {
        return price;
    }


    public void setPrice(String price) {
        this.price.set(price);
    }

    public SellerAndOrderTableData(String uid, String pid,
                                   String identifier, String price) {
        this.uid = new SimpleStringProperty(uid);
        this.pid = new SimpleStringProperty(pid);
        this.identifier = new SimpleStringProperty(identifier);
        this.price = new SimpleStringProperty(price);
    }
}
