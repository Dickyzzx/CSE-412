package com.demo;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

public class Main extends Application {


    private Stage primaryStage;

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        loginInit();
    }

    private void loginInit() {

        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("/view/Login.fxml"));
            primaryStage.setTitle("Pet Mall");
            primaryStage.getIcons().add(new Image("/logo/logo_icon1.jpg"));
            primaryStage.setResizable(false);
            primaryStage.setScene(new Scene(root));
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Stage homePageInit() {
        Stage homePageStage = null;
        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("/view/Homepage.fxml"));
            homePageStage = new Stage();
            homePageStage.setTitle("Pet Mall Index");
            homePageStage.getIcons().add(new Image("/logo/logo_icon1.jpg"));
            homePageStage.setResizable(false);
            homePageStage.setAlwaysOnTop(false);
            homePageStage.initOwner(primaryStage);
            homePageStage.setScene(new Scene(root));
            return homePageStage;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public AnchorPane initMainFrame(String url) {
        try {
            // 加载FXML布局文件
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource(url));
            AnchorPane root = loader.load();
            return root;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public Stage registerPageInit() {
        Stage registerPageStage = null;
        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("/view/Register.fxml"));
            registerPageStage = new Stage();
            registerPageStage.setTitle("User Register");
            registerPageStage.getIcons().add(new Image("/logo/logo_icon1.jpg"));
            registerPageStage.setResizable(false);
            registerPageStage.initOwner(primaryStage);
            registerPageStage.setScene(new Scene(root));
            return registerPageStage;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }

    }
}
